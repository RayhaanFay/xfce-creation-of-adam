# yuune-xfwm-themes
gallery of my xfwm themes

# Previews :

##### InVSBL : Theme with invisible buttons, hover to see the buttons
![InVSBL](previews/invsbl.png)

##### InVSBL-Dark : dark version
![InVSBL-Dark](previews/invsbl-dark.png)

##### Avrora : Xfwm with unique button
![Avrora](previews/avrora.png)

##### Avrora-Dark : dark version
![Avrora-Dark](previews/avrora-dark.png)

##### Avrora-Ein : thick border and rounded corner
![Avrora-Ein](previews/avrora-ein.png)

##### Avrora-Ein-Dark : dark title bar, thick border and rounded corner
![Avrora-Ein-Dark](previews/avrora-ein-dark.png)


##### Stick : freaking-minimal theme
![Stick](previews/stick.png)
