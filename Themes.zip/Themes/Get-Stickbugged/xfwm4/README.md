# Stick-xfwm4
Very Minimalist themes for XFWM

## Installation
- copy to the .themes folder

## Editing colors
run build.sh and follow the instruction
```
sh build.sh
```
