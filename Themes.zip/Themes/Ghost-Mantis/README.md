~~Mantis~~ *Ghost Mantis*
==========

*Mantis* is a dark gray theme for Xfce.
It's existence comes from a need for an easy-on-the-eyes workstation theme.


The GTK 2 widget theme is based on Xfce-Simple-Dark (https://github.com/trustable-code/Xfce-Simple-Dark)
Basic GTK3 support exists and is lifted from my dark gray spin of the Arc theme (https://github.com/mantissa-/arc-pro-theme)

Xfce panel theming needs some work, but it's not the worst.

Tested on Xubuntu 17.10, YMMV.

![A screenshot of Mantis](https://i.imgur.com/Mjb8o3N.png)
*Breeze icon set was used in this setup*

Installation
------------

1. Unzip and rename base folder `Mantis`, then copy into your `~/.themes/` directory.
2. Open *Appearance* and select the theme.
3. Open *Window Manager* and select the theme.

License
-------

GPLv3
